_!! Completions are automatically generated. These are not meant to be manually
edited !!_

To regenerate completions simply run:

```bash
$ cargo xtask gen
```
